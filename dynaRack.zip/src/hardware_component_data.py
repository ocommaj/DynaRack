component_data = {
    "RPiB": {
        "id": "RPiB",
        "name": "Raspberry Pi B",
        "diam": 2.5,
        "count": 4,
        "pos": [
            [ -29, -28 ],
            [ -29, 28 ],
            [ 29, -28 ],
            [ 29, 28 ]
        ]
    }
}
