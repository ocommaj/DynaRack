bl_info = {
    "name": "Set Defaults",
}

import bpy
from bpy.app.handlers import persistent

@persistent
def set_defaults(scene):
    standoff_props = scene.Standoff
    #mountpoints_props = scene.MountPoints
    standoff_props.metric_diameter = 2.5
    standoff_props.height = 3


def register():
    #bpy.app.handlers.scene_update_pre.append(set_defaults)
    bpy.app.handlers.load_post.append(set_defaults)

def unregister():
    bpy.app.handlers.load_post.remove(set_defaults)
